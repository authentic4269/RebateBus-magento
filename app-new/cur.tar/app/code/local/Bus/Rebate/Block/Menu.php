<?php
class Bus_Rebate_Block_Menu extends Mage_Core_Block_Template 
{    
    
}
?>
